using System.Net.WebSockets;
using Microsoft.EntityFrameworkCore;
using Moq;
using Waves.Api.Models;
using Waves.Api.Repositories;

namespace Waves.Api.Tests
{
    public class WaveRepositoryTests
	{
		private WavesRepository _wavesRepository;
		private AppDbContext _context;
		private DbContextOptions<AppDbContext> options;

		
		[SetUp]
		public void SetUp()
		{
			options = new DbContextOptionsBuilder<AppDbContext>()
				.UseInMemoryDatabase(databaseName: "WavesListDatabase")
				.Options;

			_context = new AppDbContext(options);
			_wavesRepository = new WavesRepository(_context);

			// Insert initial data
			_context.Waves.Add(getWave());
			_context.SaveChanges();
		}

		[Test]
		public async Task GetAllWaves()
		{
			
			// Use a clean instance of the context to run the test
			using (var context = new AppDbContext(options))
			{
				WavesRepository waveRepository = new WavesRepository(context);
				var result  = await waveRepository.GetAllWavesAsync();

				Assert.AreEqual(1, result.Count());
			}
		}

		[Test]
		public async Task GetWaveById()
		{
			var expectedWave = getWave();

			// Use a clean instance of the context to run the test
			using (var context = new AppDbContext(options))
			{
				WavesRepository waveRepository = new WavesRepository(context);
				var result = await waveRepository.GetWaveByIdAsync(expectedWave.Id);

				Assert.IsNotNull(result);
				Assert.AreEqual(expectedWave.Name, result.Name);
			}
		}
		[Test]
		public async Task PostWave()
		{
			
			using (var context = new AppDbContext(options))
			{
				// Create instance of WavesRepository
				WavesRepository waveRepository = new WavesRepository(context);

				// Insert scenario: Create a new wave
				var newWave = new Wave { Id = new Guid("a7e45833-64f1-47bf-961d-c73649c47355"), Name = "New Wave", WaveDate = DateTime.Now };
				await waveRepository.SaveWaveAsync(newWave);

				// Assert: Check if the wave was inserted
				var insertedWave = await context.Waves.FindAsync(newWave.Id);
				Assert.IsNotNull(insertedWave);
				Assert.AreEqual(newWave.Name, insertedWave.Name);

				// Update scenario: Update an existing wave
				var existingWave = getWave();
				//context.Waves.Add(existingWave);
				//await context.SaveChangesAsync();

				existingWave.Name = "Updated Name";
				await waveRepository.SaveWaveAsync(existingWave);

				// Assert: Check if the wave was updated
				var updatedWave = await context.Waves.FindAsync(existingWave.Id);
				Assert.IsNotNull(updatedWave);
				Assert.AreEqual(existingWave.Name, updatedWave.Name);
			}
		}

		private Wave getWave()
		{
			return  new Wave { Id = new Guid("b868f8c8-80cc-4ae0-9b4f-5ed585b6d948"), Name = "Initial Wave", WaveDate = DateTime.Now };

		}
		[TearDown]
		public void TearDown()
		{
			foreach (var wave in _context.Waves)
			{
				_context.Waves.Remove(wave);
			}
			_context.SaveChanges(); _context.Dispose();
		}
	}
}