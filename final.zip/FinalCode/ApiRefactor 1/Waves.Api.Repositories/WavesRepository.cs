﻿using System;
using Microsoft.EntityFrameworkCore;
using Waves.Api.Models;
using System.Linq;

namespace Waves.Api.Repositories
{
	public class WavesRepository : IWavesRepository
    {
		private readonly AppDbContext _context;

		public WavesRepository(AppDbContext context)
		{
			_context = context;
		}

		public async Task<List<Wave>> GetAllWavesAsync()
		{
		//	var duplicateIds = await _context.Waves
		//.GroupBy(w => w.Id)
		//.Where(g => g.Count() > 1)
		//.Select(g => g.Key)
		//.ToListAsync();

		//	foreach (var id in duplicateIds)
		//	{
		//		var duplicateEntities = await _context.Waves.Where(w => w.Id == id).ToListAsync();

		//		// Keep the first entity and delete the rest
		//		var entityToKeep = duplicateEntities.First();
		//		var entitiesToDelete = duplicateEntities.Skip(1);

		//		_context.Waves.RemoveRange(entitiesToDelete);
		//	}

		//	await _context.SaveChangesAsync();
			return await _context.Waves.ToListAsync();
		}

		public async Task<Wave> GetWaveByIdAsync(Guid id)
		{
			return await _context.Waves.FirstOrDefaultAsync(w => w.Id == id);

		}
		public async Task<bool> SaveWaveAsync(Wave wave)
		{
			try
			{
				var existingWave = await _context.Waves.FirstOrDefaultAsync(w => w.Id == wave.Id);

				if (existingWave == null)
				{
					// Insert new wave
					_context.Waves.Add(wave);
				}
				else
				{
					// Update existing wave
					_context.Entry(existingWave).CurrentValues.SetValues(wave);
				}
				await _context.SaveChangesAsync();
				foreach (var entry in _context.ChangeTracker.Entries<Wave>())
				{
					entry.Reload();
				}
				return true; // Operation succeeded
			}
			catch (Exception ex)
			{
				// Log exception
				return false; // Operation failed
			}
		}
	}

}
