﻿using Waves.Api.Models;

namespace Waves.Api.Repositories
{
	public interface IWavesRepository
	{
		Task<List<Wave>> GetAllWavesAsync();
		Task<Wave> GetWaveByIdAsync(Guid id);
		Task<bool> SaveWaveAsync(Wave wave);
	}
}