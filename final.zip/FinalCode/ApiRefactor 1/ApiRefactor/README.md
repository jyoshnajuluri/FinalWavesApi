The attached project is an API used (fictionally) at Coles to get waves of orders to stores to be picked.

You can get a list of waves, a wave by id, as well as insert/update a wave

Refactor this API to make it readable, tested and "production ready".

Please highlight your change by committing to a local repository and sending back the whole directory zipped (all relevant solution files + the .git folder)

Please do not spend more than 3 hours on this exercise. The goal is to understand HOW you code.
