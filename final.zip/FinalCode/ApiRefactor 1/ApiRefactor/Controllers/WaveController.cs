//using ApiRefactor.Models;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using Waves.Api.Models;
using Waves.Api.Orchestration;
using Waves.Api.Repositories;

namespace WavesApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WaveController : ControllerBase
{
	private readonly IWavesOrchestration _wavesOrchestration;
	public WaveController(IWavesOrchestration wavesOrchestration)
	{
		_wavesOrchestration = wavesOrchestration;

	}
	/// <summary>
	/// Retrieves all waves.
	/// </summary>
	/// <returns>A collection of waves.</returns>
	[HttpGet(Name = "Get Waves")]
	[ProducesResponseType(typeof(IEnumerable<Wave>), 200)]
	[ProducesResponseType(404)]
	public async Task<ActionResult<IEnumerable<Wave>>> Get()
    {
		var waves = await _wavesOrchestration.GetAllWavesAsync();
		if (waves == null || waves.Count == 0)
		{
			return NotFound();
		}
		return Ok(waves);
    }
	/// <summary>
	/// Retrieves a wave by its ID.
	/// </summary>
	/// <param name="id">The ID of the wave to retrieve.</param>
	/// <returns>The wave with the specified ID.</returns>
	[HttpGet("{id}", Name = "Get Waves by waveId")]
	[ProducesResponseType(StatusCodes.Status200OK)]
	[ProducesResponseType(StatusCodes.Status404NotFound)]
	public async Task<ActionResult<Wave>> Get(Guid id)
    {
		var wave = await _wavesOrchestration.GetWaveByIdAsync(id);
		if (wave == null)
		{
			return NotFound();
		}
		return Ok(wave);
	}

	// <summary>
	/// Creates a new wave.
	/// </summary>
	/// <param name="wave">The wave to create.</param>
	[HttpPost(Name = "Post Waves")]
	[ProducesResponseType(201)] 
	[ProducesResponseType(400)] 
	public async Task<IActionResult> Post([FromBody] Wave wave)
	{
		if (wave == null)
		{
			return BadRequest();
		}

		bool saveResult = await _wavesOrchestration.SaveWaveAsync(wave);
		if (saveResult)
		{
			return CreatedAtAction(nameof(Get), new { id = wave.Id }, wave);
		}
		else
		{
			return StatusCode(500, "Failed to save wave."); 
		}
	}
}
