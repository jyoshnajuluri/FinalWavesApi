﻿using Waves.Api.Models;
using Waves.Api.Repositories;

namespace Waves.Api.Orchestration
{
    public class WavesOrchestration : IWavesOrchestration
    {
        private readonly IWavesRepository _wavesRepository;
        public WavesOrchestration(IWavesRepository wavesRepository)
        {
            _wavesRepository = wavesRepository; 

		}

       public async Task<List<Wave>> GetAllWavesAsync()
        {
            List<Wave> waves = new List<Wave>();
            waves= await _wavesRepository.GetAllWavesAsync();
            return waves;
        }

		public async Task<Wave> GetWaveByIdAsync(Guid id)
        {
			Wave wave = new Wave();
			wave = await _wavesRepository.GetWaveByIdAsync(id);
			return wave;
		}

		public async Task<bool> SaveWaveAsync(Wave wave)
        {
			return await _wavesRepository.SaveWaveAsync(wave);
		}
	}
}
