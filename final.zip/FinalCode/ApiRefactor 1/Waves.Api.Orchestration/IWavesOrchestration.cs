﻿using Waves.Api.Models;

namespace Waves.Api.Orchestration
{
    public interface IWavesOrchestration
    {
		Task<List<Wave>> GetAllWavesAsync();
		Task<Wave> GetWaveByIdAsync(Guid id);
		Task<bool> SaveWaveAsync(Wave wave);
	}
}